'use strict';

var gulp = require('gulp');

gulp.task('default', ['server', 'open', 'watch', 'sass']);
