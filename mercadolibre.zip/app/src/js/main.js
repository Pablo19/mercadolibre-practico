$(document).ready(function(){
	$('#product-image figure img').zoom({
	    'width': (890 / 2) + 'px'
	});
})