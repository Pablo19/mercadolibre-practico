'use strict';

require('./gulp');
